import { PorductImageListService } from './porduct-image-list.service';
import { Component } from '@angular/core';
import { OnInit } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'FirstApp';
  
   productList:[];
  hide: any[] = [];
  compareProductList: any[] = [];


  // toggle = true;
  // toggleButton = 'Disable';

  constructor(private _productService: PorductImageListService ){} 
 
  ngOnInit(): void {
    this._productService.getProducts().subscribe((data: any) => {
             //   console.log("result"+data);
                this.productList = data;
      })
    
  }


  addToCompare(item:any,btnId){
      if(this.compareProductList.indexOf(item) !== -1) {
        this.compareProductList.splice(this.compareProductList.indexOf(item), 1);
        
        var btn = document.getElementById(btnId);
        btn.innerHTML = 'Compare';

      }else{ 
      this.compareProductList.push(item);
      var btn = document.getElementById(btnId);
       btn.innerHTML = 'Remove';
      }
    
    }  

}
