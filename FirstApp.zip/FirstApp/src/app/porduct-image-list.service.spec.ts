import { TestBed } from '@angular/core/testing';

import { PorductImageListService } from './porduct-image-list.service';

describe('PorductImageListService', () => {
  let service: PorductImageListService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PorductImageListService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
